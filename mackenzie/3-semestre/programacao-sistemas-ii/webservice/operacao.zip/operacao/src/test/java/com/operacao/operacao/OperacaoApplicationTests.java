package com.operacao.operacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OperacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
